package tp1.impl.servers.rest.DB.arguments;

public class PathArgs {
	final String path;

	public PathArgs(String path) {
		this.path = path;
	}
}